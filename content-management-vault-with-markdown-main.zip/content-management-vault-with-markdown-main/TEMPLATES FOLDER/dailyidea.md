# Good morning

---

### today's contents to be uploaded

- [ ] Item 1
- [ ] Item 2
- [ ] Item 3 

there are only three checkboxes as its only possible to upload 3 contents in one day

---

### QUICK STORY IDEA

{content}


---


