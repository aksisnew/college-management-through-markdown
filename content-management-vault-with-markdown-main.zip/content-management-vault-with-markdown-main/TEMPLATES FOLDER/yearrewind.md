# Year Rewind !

# Industry connections that helped

- 
- 
- 
- 
- 
- 

# Content that gave more returns

- 
- 
- 
- 
- 


# Goals for next year

-
- 
- 
- 
- 

# Mistakes

- 
- 
- 
- 

# Lessons 

- 
- 
- 
- 

# Current followers 

SOCIAL MEDIA 1 :
SOCIAL MEDIA 2 :
SOCIAL MEDIA 3 :
SOCIAL MEDIA 4 :
SOCIAL MEDIA 5 :
SOCIAL MEDIA 6 :

# Important contacts

- 
- 
- 
- 


Remark :
mistakes :
