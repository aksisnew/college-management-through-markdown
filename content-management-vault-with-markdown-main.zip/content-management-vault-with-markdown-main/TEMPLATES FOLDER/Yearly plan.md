## Hello!

TAGS:
FROM:
TO:

---

### content strategy for this year

{content}


---

### Gears to be changed

{content}

---

### Changes in studio

{content}

---

# SUB TARGET (tHIS PHASE)

{content}

---

## CONTENT TO UPLOAD IN THIS year

- [ ] Item 1
- [ ] Item 2
- [ ] Item 3 

- [ ] Item 1
- [ ] Item 2
- [ ] Item 3 

- [ ] Item 1
- [ ] Item 2
- [ ] Item 3 

- [ ] Item 1
- [ ] Item 2
- [ ] Item 3 

- [ ] Item 1
- [ ] Item 2
- [ ] Item 3 

- [ ] Item 1
- [ ] Item 2
- [ ] Item 3 

- [ ] Item 1
- [ ] Item 2
- [ ] Item 3 

- [ ] Item 1
- [ ] Item 2
- [ ] Item 3 

- [ ] Item 1
- [ ] Item 2
- [ ] Item 3 

- [ ] Item 1
- [ ] Item 2
- [ ] Item 3 

- [ ] Item 1
- [ ] Item 2
- [ ] Item 3 

- [ ] Item 1
- [ ] Item 2
- [ ] Item 3

- [ ] Item 1
- [ ] Item 2
- [ ] Item 3 

- [ ] Item 1
- [ ] Item 2
- [ ] Item 3 

- [ ] Item 1
- [ ] Item 2
- [ ] Item 3 

- [ ] Item 1
- [ ] Item 2
- [ ] Item 3 

- [ ] Item 1
- [ ] Item 2
- [ ] Item 3 

- [ ] Item 1
- [ ] Item 2
- [ ] Item 3

---

## SOCIAL MEDIA TARGETS

SOCIAL MEDIA 1 :
SOCIAL MEDIA 2 :
SOCIAL MEDIA 3 :
SOCIAL MEDIA 4 :
SOCIAL MEDIA 5 :
SOCIAL MEDIA 6 :

---

mistakes: 


