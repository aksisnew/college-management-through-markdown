# Content is an art, it cant be forced. Even if you do it as a job its a job of making a magnificiant piece of art

## Core theme of channle
- 
- 
- 
- 

## Collabration goals

- 
- 
- 
- 
- 
- 

## New social media profiles to make

- 
- 
- 
- 

### New content types to add

- 
- 
- 
- 
- 

