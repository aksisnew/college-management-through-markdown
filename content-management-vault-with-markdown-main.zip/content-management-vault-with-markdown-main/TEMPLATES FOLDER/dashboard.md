> [!note] Channle names
> - 
> - 
> - 
> -

---

> [!tip] Other areas of life
> - 
> - 
> - 

---

## PLAN FOR NEXT 3 MONTHS
- 
- 
- 
- 
- 
- 


---

### What not to do

- 
- 
- 
- 
- 
- 



---

#### MAIN FOCUS AREA 
 


 ---
 


