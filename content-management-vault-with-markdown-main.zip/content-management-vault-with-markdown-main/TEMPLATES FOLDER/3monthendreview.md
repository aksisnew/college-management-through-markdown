# 3month end review

# Have your targets been met?

- 
- 
- 
- 
- 
- 


# Targets Unmet

- 
- 
- 
- 
- 
- 

# Industry connections that helped

- 
- 
- 
- 
- 
- 

# Content that gave more returns

- 
- 
- 
- 
- 


# Goals for next phase 

-
- 
- 
- 
- 

# Current followers 

SOCIAL MEDIA 1 :
SOCIAL MEDIA 2 :
SOCIAL MEDIA 3 :
SOCIAL MEDIA 4 :
SOCIAL MEDIA 5 :
SOCIAL MEDIA 6 :

---

mistakes :
