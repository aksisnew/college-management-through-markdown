# Good Sunday!

---

### today's contents to be uploaded

- [ ] Item 1
- [ ] Item 2
- [ ] Item 3 

- [ ] Item 1
- [ ] Item 2
- [ ] Item 3 



---

### QUICK STORY IDEA

{content}


---

### ALTERNATIVE STORY IDEA


---

SUB TARGET (this week): 
SUB GAINED (THIS WEEK):



